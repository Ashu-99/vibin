module.exports = {
    lintOnSave: false,
    publicPath: '',
    productionSourceMap: false
}